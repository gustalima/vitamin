#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
files = os.listdir('.')
files.remove('.src')
#files.remove('gui')
files.remove('.vitamin')
print 'Removing files from old session'

for i in files:
    os.system('rm -R %s'%i)
