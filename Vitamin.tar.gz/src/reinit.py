#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os


if "vit.py" in os.listdir("../"):
    os.system('find ../ -not -name "vit.py" -not -name "vit.glade" -not -name "src" -not -name "gui" -delete')
else:
    print 'No files found'
    print 'You should not run this script here'
