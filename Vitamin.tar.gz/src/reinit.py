#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
files = os.listdir('.')
files.remove('src')
files.remove('gui')
files.remove('vit.py')
print files

for i in files:
    os.system('rm -R %s'%i)
